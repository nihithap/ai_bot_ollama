import pygame
import random
import sys

# Initialize pygame
pygame.init()

# Game constants
WINDOW_WIDTH = 600
WINDOW_HEIGHT = 600
GRID_SIZE = 20
GRID_WIDTH = WINDOW_WIDTH // GRID_SIZE
GRID_HEIGHT = WINDOW_HEIGHT // GRID_SIZE
FPS = 10  # Game speed (frames per second)

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 200, 0)
RED = (255, 0, 0)
GRAY = (40, 40, 40)
DARK_GRAY = (30, 30, 30)

# Direction vectors
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)


class Snake:
    """Snake class to manage the snake's body, movement, and growth."""
    
    def __init__(self):
        """Initialize the snake with a starting position and direction."""
        # Start in the middle of the screen
        start_x = GRID_WIDTH // 2
        start_y = GRID_HEIGHT // 2
        
        # Create initial snake body (horizontal line)
        # Body extends to the LEFT from the head
        self.body = [
            (start_x, start_y),
            (start_x - 1, start_y),
            (start_x - 2, start_y),
            (start_x - 3, start_y),
            (start_x - 4, start_y),
        ]
        
        # Initial direction (moving LEFT to match body orientation)
        self.direction = LEFT
        self.next_direction = LEFT  # Buffer for direction changes
        
    def move(self):
        """Move the snake in the current direction."""
        # Calculate new head position
        head_x, head_y = self.body[-1]
        new_x = head_x + self.direction[0]
        new_y = head_y + self.direction[1]
        
        # Add new head
        self.body.append((new_x, new_y))
        
        # Remove tail (unless we're about to eat food)
        self.body.pop(0)
        
        # Update direction
        self.direction = self.next_direction
        self.next_direction = self.direction
        
    def grow(self):
        """Grow the snake by keeping the tail."""
        pass  # Tail is already kept when growing
    
    def reset(self):
        """Reset the snake to initial state."""
        start_x = GRID_WIDTH // 2
        start_y = GRID_HEIGHT // 2
        self.body = [
            (start_x, start_y),
            (start_x - 1, start_y),
            (start_x - 2, start_y),
            (start_x - 3, start_y),
            (start_x - 4, start_y),
        ]
        self.direction = LEFT
        self.next_direction = LEFT
        
    def change_direction(self, new_direction):
        """Change direction, preventing 180-degree turns."""
        # Prevent reversing direction
        if (new_direction[0] * self.direction[0] == -1 and 
            new_direction[1] * self.direction[1] == -1):
            return
        
        self.next_direction = new_direction
        
    def draw(self, screen):
        """Draw the snake on the screen."""
        for i, segment in enumerate(self.body):
            # Head is brighter, body is darker
            color = GREEN if i == 0 else DARK_GREEN
            
            rect = pygame.Rect(
                segment[0] * GRID_SIZE,
                segment[1] * GRID_SIZE,
                GRID_SIZE - 1,  # -1 for gap between segments
                GRID_SIZE - 1
            )
            pygame.draw.rect(screen, color, rect)
            pygame.draw.rect(screen, BLACK, rect, 1)


class Food:
    """Food class to manage food position and spawning."""
    
    def __init__(self):
        """Initialize food at a random position."""
        self.position = self.spawn()
        
    def spawn(self, snake_body=None):
        """Spawn food at a random position not occupied by the snake."""
        while True:
            x = random.randint(0, GRID_WIDTH - 1)
            y = random.randint(0, GRID_HEIGHT - 1)
            if snake_body is None or (x, y) not in snake_body:
                return (x, y)
        
    def draw(self, screen):
        """Draw the food on the screen."""
        rect = pygame.Rect(
            self.position[0] * GRID_SIZE,
            self.position[1] * GRID_SIZE,
            GRID_SIZE - 1,
            GRID_SIZE - 1
        )
        pygame.draw.rect(screen, RED, rect)
        pygame.draw.rect(screen, BLACK, rect, 1)
        
        # Add a small highlight for visual appeal
        highlight_rect = pygame.Rect(
            self.position[0] * GRID_SIZE + 2,
            self.position[1] * GRID_SIZE + 2,
            GRID_SIZE - 5,
            GRID_SIZE - 5
        )
        pygame.draw.rect(screen, (255, 100, 100), highlight_rect)


class Game:
    """Main game class to manage game state and loop."""
    
    def __init__(self):
        """Initialize the game."""
        # Create display
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption('Snake Game')
        
        # Create clock
        self.clock = pygame.time.Clock()
        
        # Create game objects
        self.snake = Snake()
        self.food = Food()
        
        # Game state
        self.score = 0
        self.high_score = 0
        self.game_over = False
        self.paused = False
        self.running = True
        
        # Font for score display
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        
        # Speed increase settings
        self.base_fps = FPS
        self.max_fps = 20
        self.speed_increase = 0.5
        
    def handle_events(self):
        """Handle pygame events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                elif event.key == pygame.K_UP or event.key == pygame.K_w:
                    self.snake.change_direction(UP)
                elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
                    self.snake.change_direction(DOWN)
                elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                    self.snake.change_direction(LEFT)
                elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                    self.snake.change_direction(RIGHT)
                elif event.key == pygame.K_SPACE:
                    self.paused = not self.paused
                elif event.key == pygame.K_r and self.game_over:
                    self.reset_game()
    
    def reset_game(self):
        """Reset the game to initial state."""
        self.snake.reset()
        self.food = Food()
        self.score = 0
        self.game_over = False
        self.paused = False
        
    def check_collisions(self):
        """Check for wall and self-collision."""
        head = self.snake.body[-1]
        
        # Wall collision - use > for upper bounds to avoid immediate collision
        if (head[0] < 0 or head[0] > GRID_WIDTH - 1 or
            head[1] < 0 or head[1] > GRID_HEIGHT - 1):
            self.game_over = True
            return True
            
        # Self collision
        if head in self.snake.body[:-1]:  # Exclude head itself
            self.game_over = True
            return True
            
        return False
    
    def check_food_collision(self):
        """Check if snake ate food."""
        head = self.snake.body[-1]
        if head == self.food.position:
            self.score += 10
            self.food = Food()
            # Update high score
            if self.score > self.high_score:
                self.high_score = self.score
            return True
        return False
    
    def update(self):
        """Update game state."""
        if self.paused or self.game_over:
            return
            
        self.snake.move()
        
        if self.check_food_collision():
            self.snake.grow()
            
        if self.check_collisions():
            self.game_over = True
    
    def draw(self):
        """Draw everything on the screen."""
        # Clear screen
        self.screen.fill(BLACK)
        
        # Draw grid (optional, for visual reference)
        for x in range(GRID_WIDTH + 1):
            pygame.draw.line(self.screen, GRAY, 
                           (x * GRID_SIZE, 0), 
                           (x * GRID_SIZE, WINDOW_HEIGHT))
        for y in range(GRID_HEIGHT + 1):
            pygame.draw.line(self.screen, GRAY, 
                           (0, y * GRID_SIZE), 
                           (WINDOW_WIDTH, y * GRID_SIZE))
        
        # Draw snake
        self.snake.draw(self.screen)
        
        # Draw food
        self.food.draw(self.screen)
        
        # Draw score
        score_text = self.font.render(f'Score: {self.score}', True, WHITE)
        high_score_text = self.font.render(f'High Score: {self.high_score}', True, WHITE)
        self.screen.blit(score_text, (10, 10))
        self.screen.blit(high_score_text, (10, 50))
        
        # Draw pause message
        if self.paused:
            pause_text = self.font.render('PAUSED - Press SPACE to continue', True, WHITE)
            text_rect = pause_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2))
            self.screen.blit(pause_text, text_rect)
        
        # Draw game over message
        if self.game_over:
            game_over_text = self.font.render('GAME OVER - Press R to restart', True, WHITE)
            text_rect = game_over_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2))
            self.screen.blit(game_over_text, text_rect)
            
            # Draw restart hint
            restart_hint = self.small_font.render('Press R to restart', True, GRAY)
            hint_rect = restart_hint.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 + 30))
            self.screen.blit(restart_hint, hint_rect)
        
        # Update display
        pygame.display.flip()
    
    def run(self):
        """Main game loop."""
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            
            # Gradually increase speed as score increases
            current_fps = min(self.base_fps + (self.score // 5) * self.speed_increase, self.max_fps)
            self.clock.tick(current_fps)
            
        # Cleanup
        pygame.quit()
        sys.exit()


def main():
    """Entry point for the game."""
    game = Game()
    game.run()


if __name__ == '__main__':
    main()